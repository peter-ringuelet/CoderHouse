from setuptools import setup

setup(
    name='pre-entrega2-Ringuelet',
    version='0.1.0',
    author='Pedro Ringuelet',
    author_email='pedroringuelet@gmail.com',
    description='pre-entrega del curso de Python de CoderHouse',
    packages=['paquete_cliente', 'paquete_persona']
)